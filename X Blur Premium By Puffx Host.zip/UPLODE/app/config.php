<?php
$url = $_SERVER["SERVER_NAME"];  
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://puffxlivehost.cloud');
define('STYLESHEETS_URL', '//puffxlivehost.cloud' );
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);
return [
  'db' => [
    'name'    =>  'puffxliv_puffx' ,
    'host'    =>  'localhost',
    'user'    =>  'puffxliv_puffx' ,
    'pass'    =>  'R7D?m&aKHu@[' ,
    'charset' =>  'utf8mb4' 
  ]
];
?>